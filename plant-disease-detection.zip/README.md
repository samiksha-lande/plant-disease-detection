# Plant Disease Detection
Intermediate project using MobileNetV2 and full PlantVillage dataset.
